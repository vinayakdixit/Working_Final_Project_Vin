// window.onload= function (){

function myFunction() {
  var age = document.getElementById("age").value;
  var gender = document.getElementById("gender").value;
  var height = document.getElementById("height").value;
  var weight = document.getElementById("weight").value;
  var ap_hi = document.getElementById("ap_hi").value;
  var ap_low = document.getElementById("ap_low").value;
  var cholesterol = document.getElementById("cholesterol").value;
  var gluc = document.getElementById("gluc").value;
  var smoke = document.getElementById("smoke").value;
  var alco = document.getElementById("alco").value;
  var active = document.getElementById("active").value;
  var bmi = document.getElementById("bmi").value;





  }

// var nameInput = document.getElementById('age');

// document.querySelector('form.myForm').addEventListener("onclick", function (e) {

//     e.preventDefault();

//     console.log(nameInput.value);    
// });

